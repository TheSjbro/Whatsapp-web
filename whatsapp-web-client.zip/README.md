# WhatsApp Web Client (Demo)

A minimal web client for WhatsApp built using the **WhatsApp Cloud API**.  
Backend: Node.js/Express.  
Frontend: Static HTML + vanilla JS.  
Messages are proxied via your backend; incoming messages are streamed to the browser with SSE.

---

## 🚀 Features
- Send text messages to WhatsApp users.
- Receive incoming messages in real time via webhook + SSE.
- Simple UI for demo purposes.
- Local dev setup with `ngrok`.

---

## 📂 Project Structure
```
whatsapp-web-client/
├── server/          # Node/Express backend
├── client/          # Static frontend (index.html)
```

---

## ⚙️ Prerequisites
1. Node.js v16+ and npm.
2. Meta Developer Account with WhatsApp Cloud API enabled:
   - App ID and access token
   - WhatsApp Business Phone Number ID
3. A phone number connected to your WhatsApp Business Account.
4. `ngrok` (or similar) for local webhook testing.

---

## 🔧 Setup

### 1. Clone Repo
```bash
git clone https://github.com/yourname/whatsapp-web-client.git
cd whatsapp-web-client/server
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Env Vars
Create a `.env` file in `server/` based on `.env.example`.

```bash
cp .env.example .env
```

Fill in:
- `WHATSAPP_TOKEN` = Meta permanent or temporary access token  
- `PHONE_NUMBER_ID` = WhatsApp Business Phone Number ID  
- `VERIFY_TOKEN` = random string you’ll set in Meta console  
- `PORT` = (optional) default 3000  

### 4. Run the Server
```bash
npm run dev   # uses nodemon
```

### 5. Expose with ngrok
```bash
ngrok http 3000
```

Copy your ngrok URL (e.g. `https://abcd.ngrok.io`).

### 6. Configure Webhook in Meta Developer Portal
- Webhook URL: `https://abcd.ngrok.io/webhook`
- Verify token: same as in `.env`
- Subscribe to messages.

### 7. Open the Client
Simply open `client/index.html` in a browser.  
Ensure it points to your backend URL in `API_BASE`.

---

## 📝 Notes
- Outbound messages must follow WhatsApp Business rules (templates required if user hasn’t messaged in last 24h).
- Only text messages are implemented here. Extend with images, templates, or interactive messages by adjusting the backend `/send` endpoint.
- For production: verify webhook signatures (`X-Hub-Signature`).

---

## 📜 License
MIT
